package com.idat.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idat.demo.interfaceService.IUsuarioService;
import com.idat.demo.interfaces.IUsuario;

import com.idat.demo.modelo.Usuario;

public class UsuarioService {


	@Autowired
	IUsuario data;
	
	
	
	public List<Usuario> listar() {
		return (List<Usuario>)data.findAll();
	}

	
	public Optional<Usuario> listarId(int id) {
		return data.findById(id);
	}

	
	public int save(Usuario us) {
		int res=0;
		Usuario productos=data.save(us);
			if(!productos.equals(null)) {
				res=1;
			}
		return 0;
	}

	
	public void delete(int id) {
		data.deleteById(id);
		
	}

}
