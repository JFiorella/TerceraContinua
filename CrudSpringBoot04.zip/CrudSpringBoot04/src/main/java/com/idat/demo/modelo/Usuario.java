package com.idat.demo.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Usuario")
public class Usuario {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int id;
	@Column (name="name" , length = 50)
	private String usuario;
	@Column (name="name" , length = 50)
	private String password;
;
	
	public Usuario() {
		
	}
	
	public Usuario(int id, String usuario, String password) {
		super();
		this.id = id;
		this.usuario = usuario;
		this.password = password;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	public void setNombre(String string) {
		// TODO Auto-generated method stub
		
	}
	public void setClave(String encode) {
		// TODO Auto-generated method stub
		
	}
	public Object getNombre() {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
