package com.idat.demo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.idat.demo.interfaces.IUsuario;

import com.idat.demo.modelo.Usuario;

public class RestUsuario {


	@Autowired
	private IUsuario data;

	@GetMapping(value ="/{id}")
	public List<Usuario> buscar() {
	return (List<Usuario>)data.findAll();
	}

	@GetMapping
	public List<Usuario> listar() {
		return (List<Usuario>)data.findAll();
	}

	@PostMapping
	public void insertar(@RequestBody Usuario user) {
	data.save(user);
	}
	@PutMapping
	public void modificar(@RequestBody Usuario user) {
		data.save(user);
	}

	@DeleteMapping(value ="/{id}")
	public void eliminar(@PathVariable("id") Integer id) {
		data.deleteById(id);
	}

	}