package com.idat.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idat.demo.interfaceService.ICategoriasService;
import com.idat.demo.interfaces.ICategorias;
import com.idat.demo.modelo.Categorias;

@Service
public class CategoriasService {


	@Autowired
	ICategorias data;
	
	public List<Categorias> listar() {
		return (List<Categorias>)data.findAll();
	}

	
	public Optional<Categorias> listarId(int id) {
		return data.findById(id);
	}

	
	public int save(Categorias c) {
		int res=0;
		Categorias categorias=data.save(c);
			if(!categorias.equals(null)) {
				res=1;
			}
		return 0;
	}

	
	public void delete(int id) {
		data.deleteById(id);
		
	}

}
