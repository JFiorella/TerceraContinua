package com.idat.demo.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Productos")
public class Productos {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int id;
	private String nombre;
	private int proveedor;
	private int categorias;
	private String catidad;
	private int precio;
	
	public Productos() {
		
	}

	public Productos(int id, String nombre, int proveedor, int categorias, String catidad, int precio) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.proveedor = proveedor;
		this.categorias = categorias;
		this.catidad = catidad;
		this.precio = precio;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getProveedor() {
		return proveedor;
	}

	public void setProveedor(int proveedor) {
		this.proveedor = proveedor;
	}

	public int getCategorias() {
		return categorias;
	}

	public void setCategorias(int categorias) {
		this.categorias = categorias;
	}

	public String getCatidad() {
		return catidad;
	}

	public void setCatidad(String catidad) {
		this.catidad = catidad;
	}

	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	public void setClave(String encode) {
		// TODO Auto-generated method stub
		
	}

	

	
}
