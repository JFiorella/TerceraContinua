package com.idat.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idat.demo.interfaceService.IProductosService;
import com.idat.demo.interfaces.IProductos;
import com.idat.demo.modelo.Productos;

@Service
public class ProductosService {



	@Autowired
	IProductos data;
	
	
	
	public List<Productos> listar() {
		return (List<Productos>)data.findAll();
	}

	
	public Optional<Productos> listarId(int id) {
		return data.findById(id);
	}

	
	public int save(Productos p) {
		int res=0;
		Productos productos=data.save(p);
			if(!productos.equals(null)) {
				res=1;
			}
		return 0;
	}

	
	public void delete(int id) {
		data.deleteById(id);
		
	}

}
