package com.idat.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.idat.demo.Seguridad.UsuarioSeguridad;
import com.idat.demo.interfaces.IUsuario;
import com.idat.demo.modelo.Usuario;

 

@Configuration
@EnableWebMvc

public class SeguridadConfig {
	@Autowired
	private UsuarioSeguridad userDetailsService;
	@Autowired
	private BCryptPasswordEncoder bcrypt;
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
	BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
	return bCryptPasswordEncoder;
	}
	@Override
	protected void configure(AuthenticationManagerBuilder auth)
	throws Exception{
	auth.userDetailsService(userDetailsService).passwordEncoder(bcrypt);
	}
	@Override
	protected void configure(HttpSecurity http) throws Exception{
	http
	.authorizeRequests()
	.anyRequest()
	.authenticated()
	.and()
	.httpBasic();
	}   }

