package com.idat.demo;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;


import com.idat.demo.interfaces.IUsuario;
import com.idat.demo.modelo.Usuario;

@RunWith(SpringRunner.class)
@SpringBootTest
class CrudSpringBoot04ApplicationTests {

	@Autowired
	private	BCryptPasswordEncoder encoder;

	@Autowired
	private IUsuario repo;
	
	@Test
	public void crearUsuariTest() {
	Usuario us = new Usuario();
	
	us.setId(5);
	us.setNombre("usuario5");
	us.setClave(encoder.encode("12345"));
	
	Usuario retorno = repo.save(us);
	assertTrue(retorno.getClass().equalsIgnoreCase(us.getClass()));
	}	

}

